<?php
$servername = "localhost";
$username = "edukubm4_form";  // ← это твой пользователь
$password = "Nikitapusia123";          // ← это твой пароль
$dbname = "edukubm4_form";    // ← это и имя базы данных

// Создаем соединение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем соединение
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
?>
