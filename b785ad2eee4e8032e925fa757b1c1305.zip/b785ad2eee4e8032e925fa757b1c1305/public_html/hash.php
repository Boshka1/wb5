<?php
     echo password_hash('Admin1234', PASSWORD_DEFAULT);
     ?>